import User from "../models/user.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { OAuth2Client } from 'google-auth-library';
import geoip from "geoip-lite";
import { seedPlacesAround } from "../services/seedHelper.js";

const JWT_SECRET = process.env.JWT_SECRET || "supersecret";

// Register a new user
export const registerUser = async (req, res) => {
	const { name, email, password, preferences, location: bodyLocation } = req.body;

	try {
		const hashed = await bcrypt.hash(password, 10);

		// 🌍 Step 1: Use location from body if provided
		let location = bodyLocation;

		// 🌍 Step 2: If no location in body, try to auto-detect from IP
		if (!location) {
			const rawIp = req.headers["x-forwarded-for"] || req.connection.remoteAddress || req.ip;
			const ip = rawIp.split(",")[0]?.trim();
			const geo = geoip.lookup(ip);

			if (geo?.ll) {
				location = {
					city: geo.city || geo.region || "Unknown",
					lat: geo.ll[0],
					lng: geo.ll[1],
				};
				console.log("🌐 GeoIP success:", location);
			} else {
				// 🌍 Step 3: Fallback to default (Delhi)
				location = {
					city: "Delhi",
					lat: 28.6139,
					lng: 77.209,
				};
				console.warn("⚠️ GeoIP failed. Using default location: Delhi");
			}
		}

		// 🔐 Create user
		const user = new User({
			name,
			email,
			password: hashed,
			preferences,
			location,
		});

		await user.save();
		res.status(201).json({ message: "User registered", userId: user._id });
	} catch (err) {
		res.status(500).json({ message: "Registration failed", error: err.message });
	}
};

// Google OAuth verification
export const googleVerify = async (req, res) => {
	try {
		const { credential } = req.body;
		console.log("Received Google credential:", credential);

		if (!credential) {
			return res.status(400).json({ message: "No credential provided" });
		}

		// Create OAuth2Client
		const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);
		
		// Verify the token
		const ticket = await client.verifyIdToken({
			idToken: credential,
			audience: process.env.GOOGLE_CLIENT_ID
		});

		const payload = ticket.getPayload();
		console.log("Google payload:", payload);

		// Check if user exists
		let existingUser = await User.findOne({ email: payload.email });

		if (!existingUser) {
			// Get location from IP
			const rawIp = req.headers["x-forwarded-for"] || req.connection.remoteAddress || req.ip;
			const ip = rawIp.split(",")[0]?.trim();
			const geo = geoip.lookup(ip);

			// Create new user
			existingUser = await User.create({
				name: payload.name,
				email: payload.email,
				googleId: payload.sub,
				location: geo?.ll ? {
					city: geo.city || geo.region || "Unknown",
					lat: geo.ll[0],
					lng: geo.ll[1],
				} : {
					city: "Delhi",
					lat: 28.6139,
					lng: 77.209,
				}
			});
			console.log("Created new user:", existingUser);
		}

		// Generate JWT token
		const token = jwt.sign(
			{ userId: existingUser._id },
			JWT_SECRET,
			{ expiresIn: '7d' }
		);

		// Send response
		res.json({
			user: {
				id: existingUser._id,
				name: existingUser.name,
				email: existingUser.email
			},
			token
		});
	} catch (error) {
		console.error('Google verification error:', error);
		res.status(400).json({ 
			message: 'Failed to verify Google token',
			error: error.message 
		});
	}
};

// Login
export const loginUser = async (req, res) => {
	const { email, password } = req.body;

	try {
		const user = await User.findOne({ email });
		if (!user) return res.status(404).json({ message: "User not found." });

		const isMatch = await bcrypt.compare(password, user.password);
		if (!isMatch) return res.status(401).json({ message: "Invalid credentials." });

		const token = jwt.sign({ userId: user._id }, JWT_SECRET, {
			expiresIn: "7d",
		});

		res.json({ token, user: { id: user._id, name: user.name, email: user.email } });
	} catch (err) {
		res.status(500).json({ message: "Server error", error: err.message });
	}
};

// Get user profile
export const getUserProfile = async (req, res) => {
	try {
		console.log("Backend: getUserProfile - Authenticated user ID:", req.user.userId);
		const user = await User.findById(req.user.userId).select("-password");
		if (!user) {
			console.log("Backend: getUserProfile - User not found for ID:", req.user.userId);
			return res.status(404).json({ message: "User not found." });
		}
		console.log("Backend: getUserProfile - Sending user data:", user.email, "Preferences:", user.preferences);
		res.json(user);
	} catch (err) {
		console.error("Backend: getUserProfile - Server error:", err.message);
		res.status(500).json({ message: "Server error", error: err.message });
	}
};

// Update user profile
export const updateUserProfile = async (req, res) => {
	const { name, preferences } = req.body;
	console.log("Backend: updateUserProfile - Authenticated user ID:", req.user.userId);
	console.log("Backend: updateUserProfile - Received preferences:", preferences);

	try {
        console.log("Backend: updateUserProfile - Attempting to update user preferences...");
		const user = await User.findByIdAndUpdate(
			req.user.userId,
			{ name, preferences },
			{ new: true }
		).select("-password");

		if (!user) {
			console.log("Backend: updateUserProfile - User not found for ID:", req.user.userId);
			return res.status(404).json({ message: "User not found." });
		}
		console.log("Backend: updateUserProfile - Successfully updated user:", user.email, "New preferences:", user.preferences);
		res.json(user);
	} catch (err) {
		console.error("Backend: updateUserProfile - Server error during update:", err.message);
		res.status(500).json({ message: "Server error", error: err.message });
	}
};

// Change password
export const changePassword = async (req, res) => {
	const { currentPassword, newPassword } = req.body;

	try {
		const user = await User.findById(req.user.userId);
		const isMatch = await bcrypt.compare(currentPassword, user.password);
		if (!isMatch) return res.status(401).json({ message: "Current password is incorrect." });

		user.password = await bcrypt.hash(newPassword, 10);
		await user.save();

		res.json({ message: "Password updated successfully." });
	} catch (err) {
		res.status(500).json({ message: "Server error", error: err.message });
	}
};
