import { googleTextSearch, googleNearbySearch, googleDetails } from "../services/googleService.js";
import Place from "../models/place.js";

/**
 * GET /api/places/search
 * Either:
 *   /search?q=temples+in+goa
 * or
 *   /search?lat=12.97&lng=77.59&radius=3000&type=park
 */
export const searchPlaces = async (req, res) => {
	const { q, lat, lng, radius, type } = req.query;

	try {
		let results;

		if (lat && lng && radius) {
			// Nearby Search
			results = await googleNearbySearch({
				lat: parseFloat(lat),
				lng: parseFloat(lng),
				radius: parseInt(radius),
				type,
			});
		} else if (q) {
			// Text Search
			results = await googleTextSearch(q);
		} else {
			return res.status(400).json({ message: "Provide either q OR lat/lng/radius" });
		}

		res.json(results);
	} catch (err) {
		res.status(500).json({ message: "Google search failed", error: err.message });
	}
};

/**
 * GET /api/places/details/:placeId
 * Returns cached details or fetches from Google and caches.
 */
export const getPlaceDetails = async (req, res) => {
	const { placeId } = req.params;

	try {
		// Try cache first
		let place = await Place.findOne({ placeId });

		if (!place) {
			const details = await googleDetails(placeId);
			place = await Place.create(details); // persist in DB
		}

		res.json(place);
	} catch (err) {
		res.status(500).json({ message: "Failed to fetch place details", error: err.message });
	}
};

/**
 * GET /api/places/saved
 * Returns up to 20 cached places, ordered by rating desc
 */
export const getSavedPlaces = async (req, res) => {
	try {
		const places = await Place.find().sort({ rating: -1 }).limit(20);
		res.json(places);
	} catch (err) {
		res.status(500).json({ message: "Failed to fetch saved places", error: err.message });
	}
};

// POST /api/places/save
// Body: { placeId, name, location: { lat, lng }, types, rating, address, photoUrl }
export const savePlace = async (req, res) => {
	const { placeId, name, location, types, rating, address, photoUrl } = req.body;

	if (!placeId || !name || !location || !location.lat || !location.lng) {
		return res.status(400).json({ message: "Missing required fields" });
	}

	try {
		let existing = await Place.findOne({ placeId });
		if (existing) {
			return res.status(409).json({ message: "Place already exists", place: existing });
		}

		const place = await Place.create({
			placeId,
			name,
			location,
			types,
			rating,
			address,
			photoUrl,
		});

		res.status(201).json({ message: "Place saved successfully", place });
	} catch (err) {
		res.status(500).json({ message: "Failed to save place", error: err.message });
	}
};
