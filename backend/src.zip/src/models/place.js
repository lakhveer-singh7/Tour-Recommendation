import mongoose from "mongoose";

const placeSchema = new mongoose.Schema({
	placeId: {
		type: String,
		required: true,
		unique: true,
	},

	name: {
		type: String,
		required: true,
	},

	location: {
		lat: { type: Number, required: true },
		lng: { type: Number, required: true },
	},

	types: [String], // e.g. ["restaurant", "tourist_attraction"]

	rating: {
		type: Number,
	},

	address: {
		type: String,
	},

	photoUrl: {
		type: String,
	},
});

export default mongoose.model("Place", placeSchema);
