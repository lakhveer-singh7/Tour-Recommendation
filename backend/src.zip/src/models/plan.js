import mongoose from "mongoose";

const planSchema = new mongoose.Schema({
	user: {
		type: mongoose.Schema.Types.ObjectId,
		ref: "User",
		required: true,
	},

	sourceLocation: {
		lat: { type: Number, required: true },
		lng: { type: Number, required: true },
	},

	selectedPlaces: [
		{
			place: {
				type: mongoose.Schema.Types.ObjectId,
				ref: "Place",
				required: true,
			},
			stayDuration: {
				type: Number, // in minutes
				required: true,
			},
			arrivalTime: {
				type: String, // optional, e.g. "10:30 AM"
			},
		},
	],

	totalTime: {
		Days: { type: Number, required: true },
		Hours: {
			type: Number,
			required: true,
		},
	},

	isSorted: {
		type: Boolean,
		default: false,
	},

	createdAt: {
		type: Date,
		default: Date.now,
	},
});

export default mongoose.model("Plan", planSchema);
