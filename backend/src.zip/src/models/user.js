import mongoose from "mongoose";
import geoip from "geoip-lite";

const userSchema = new mongoose.Schema({
	name: {
		type: String,
		required: true,
		trim: true,
	},

	email: {
		type: String,
		required: true,
		unique: true,
		lowercase: true,
	},

	password: {
		type: String,
		// Make password not required if using Google OAuth
		required: function() { return !this.googleId; } // Password is required if no googleId
	},

	// Add googleId for OAuth integration
	googleId: {
		type: String,
		unique: true,
		sparse: true, // Allows null values, important if not all users have a googleId
	},

	// either array-of-strings or detailed object – keep it simple here
	preferences: [String],

	// 🔥 NEW: auto‑filled location
	location: {
		city: String,
		lat: Number,
		lng: Number,
	},

	createdAt: {
		type: Date,
		default: Date.now,
	},
});

/* ------------------------------------------------------------------ */
/*  AUTO‑FILL LOCATION (optional)                                     */
/* ------------------------------------------------------------------ */
userSchema.pre("save", function (next) {
	// If location already provided, skip
	if (this.location && this.location.city) return next();

	// `this._reqIp` will be attached from the controller (see below)
	if (!this._reqIp) return next();

	const geo = geoip.lookup(this._reqIp);
	if (geo) {
		this.location = {
			city: geo.city || geo.region || "Unknown",
			lat: geo.ll[0],
			lng: geo.ll[1],
		};
	}
	next();
});

/* ------------------------------------------------------------------ */
/*  EXPORT (with overwrite guard)                                     */
/* ------------------------------------------------------------------ */
export default mongoose.models.User || mongoose.model("User", userSchema);
