import express from "express";
import {
	searchPlaces,
	getPlaceDetails,
	getSavedPlaces,
	savePlace,
} from "../controllers/placeController.js";
import auth from "../middleware/auth.js";

const router = express.Router();

/* ------------------------------------------------------------------
   /api/place
-------------------------------------------------------------------*/

// Public (or protect with auth if you prefer)
router.get("/search", searchPlaces);

// Needs JWT because it reveals user cache / quota usage
router.get("/details/:placeId", auth, getPlaceDetails);

// Get cached places from MongoDB – JWT required
router.get("/saved", auth, getSavedPlaces);

// POST /api/places/save
router.post("/save", auth, savePlace);

export default router;

// GET /api/places/search?q=temples in goa

// GET /api/places/search?lat=28.6139&lng=77.2090&radius=5000&type=restaurant

// GET /api/places/details/ChIJL_P_CXMEDTkRw0ZdG-0GVvw   (Auth header required)

// GET /api/places/saved                                   (Auth header required)
