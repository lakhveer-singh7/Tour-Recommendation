import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";
import authRouter from "./routes/authRoutes.js";
import planRouter from "./routes/planRoutes.js";
import placeRouter from "./routes/placeRoutes.js";
import recommendRouter from "./routes/recommendRoute.js";
import placesRouter from "./routes/placesRoutes.js";
import directionsRouter from "./routes/directionsRoutes.js";
import { connectDB } from "./config/db.js";
import passport from "passport";
import session from "express-session";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const envPath = path.resolve(__dirname, "../.env");
console.log("Checking if .env file exists at:", envPath);
console.log("File exists:", fs.existsSync(envPath));

if (fs.existsSync(envPath)) {
	console.log("Reading .env file contents:");
	console.log(fs.readFileSync(envPath, 'utf8'));
}

// Configure dotenv to look for .env in the backend directory
dotenv.config({ path: envPath });

console.log("Current directory:", __dirname);
console.log("Loading .env file from:", envPath);
console.log("Server Startup: GOOGLE_MAPS_API_KEY loaded:", process.env.GOOGLE_MAPS_API_KEY);
console.log('All environment variables:', process.env);

const app = express();

// CORS configuration
app.use(cors({
	origin: ['http://localhost:3005', 'http://localhost:3000'],
	credentials: true,
	methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
	allowedHeaders: ['Content-Type', 'Authorization']
}));

// Body parser middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(session({
	secret: process.env.JWT_SECRET,
	resave: false,
	saveUninitialized: false
}));

app.use(passport.initialize());
app.use(passport.session());

// Debug middleware
app.use((req, res, next) => {
	console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`, {
		body: req.body,
		headers: req.headers
	});
	next();
});

app.use("/api/auth", authRouter);
app.use("/api/plan", planRouter);
app.use("/api/place", placeRouter);
app.use("/api/recommender", recommendRouter);
app.use("/api/places", placesRouter);
app.use("/api/directions", directionsRouter);

// Error handling middleware
app.use((err, req, res, next) => {
	console.error('Error:', err);
	res.status(500).json({ 
		message: 'Something went wrong!',
		error: process.env.NODE_ENV === 'development' ? err.message : undefined
	});
});

const PORT = process.env.PORT || 5002;

// Connect to database and start server
connectDB().then(() => {
	app.listen(PORT, () => {
		console.log(`Server running on port ${PORT}`);
	});
});

//mongodb+srv://lakhveers:sS52qVPeLF9hCcyT@cluster0.kihe7bi.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0
