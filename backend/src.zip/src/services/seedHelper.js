import axios from "axios";
import Place from "../models/place.js";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import { wikidataImage, unsplashImage } from "./photoHelper.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.resolve(__dirname, "../../.env") });

const API_KEY = process.env.GEOAPIFY_API_KEY;
const BASE = "https://api.geoapify.com/v2/places";

export const seedPlacesAround = async ({ lat, lng, city = "Unknown", radius = 5000 }) => {
	try {
		const categories = "tourism.sights,entertainment.museum,leisure.park";
		const url = `${BASE}?categories=${categories}&filter=circle:${lng},${lat},${radius}&bias=proximity:${lng},${lat}&limit=20&apiKey=${API_KEY}`;

		const { data } = await axios.get(url);
		const places = [];

		for (const feature of data.features) {
			const props = feature.properties;
			const placeId = props.place_id;
			if (await Place.findOne({ placeId })) continue;

			/* 🔍 1) Try Wikidata → Commons */
			let photoUrl = await wikidataImage(props.wikidata);

			/* 🔍 2) Else Unsplash fallback */
			if (!photoUrl && props.name) {
				photoUrl = await unsplashImage(props.name);
			}

			const place = {
				placeId,
				name:
					props.name ||
					props.address_line2 ||
					props.street ||
					props.city ||
					"Unnamed Place",
				location: {
					lat: feature.geometry.coordinates[1],
					lng: feature.geometry.coordinates[0],
				},
				types: props.categories || ["unknown"],
				rating: props.rank?.popularity
					? parseFloat((props.rank.popularity / 10).toFixed(1))
					: Math.random() * 2 + 3,
				address: props.address_line2 || props.street || props.city || city,
				photoUrl, // now populated if found
			};

			await Place.create(place);
			console.log("📍 Added:", place.name);
			places.push(place);
		}

		console.log(`✅ Seeded ${places.length} places from Geoapify near ${city}`);
		return places;
	} catch (err) {
		console.error("❌ Geoapify seeding failed:", err.response?.data || err.message);
		return [];
	}
};
